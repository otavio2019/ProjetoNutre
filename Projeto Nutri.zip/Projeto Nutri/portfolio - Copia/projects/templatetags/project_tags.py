from django import template
from django.utils.html import format_html_join, format_html

register = template.Library()

@register.filter(name='join_technologies')
def join_technologies(tecnologias):
    """Retorna uma string HTML de badges coloridos para as tecnologias."""
    try:
        if tecnologias and hasattr(tecnologias, 'exists') and tecnologias.exists():
            return format_html_join('\n', '<span class="badge bg-{0} me-1">{1}</span>', ((tech.cor, tech.nome) for tech in tecnologias.all()))
        else:
            return format_html('<small class="text-muted">Nenhuma tecnologia listada.</small>')
    except Exception as e:
        print(f"ERROR in join_technologies tag: {e}") 
        return format_html('<small class="text-muted">Erro ao listar techs.</small>')

@register.simple_tag
def project_card_class(loop_counter):
    """Define uma classe para o card do projeto baseado no contador do loop (exemplo)."""
    # Exemplo simples, poderia ser usado para alternar estilos ou algo mais complexo
    if loop_counter % 2 == 0:
        return "even-project-card"
    return "odd-project-card" 