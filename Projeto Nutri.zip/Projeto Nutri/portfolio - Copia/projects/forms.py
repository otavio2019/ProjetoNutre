from django import forms
from .models import Projeto, Tecnologia

class ProjetoForm(forms.ModelForm):
    tecnologias = forms.ModelMultipleChoiceField(
        queryset=Tecnologia.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False,
        label="Selecione as tecnologias utilizadas"
    )

    class Meta:
        model = Projeto
        fields = [
            'titulo',
            'descricao',
            'imagem',
            'link_repositorio',
            'link_aplicacao',
            'tecnologias',
            'destaque'
        ]
        widgets = {
            'descricao': forms.Textarea(attrs={'rows': 4}),
        }
        labels = {
            'titulo': "Nome do Paciente",
            'link_repositorio': "Link do Repositório (GitHub, GitLab, etc.)",
            'link_aplicacao': "Link da Aplicação (se houver)",
            'destaque': "Destacar este projeto na página inicial?"
        }
        help_texts = {
            'imagem': "Selecione uma imagem representativa para o seu projeto.",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Adicionar classes CSS ou outros atributos se necessário
        self.fields['titulo'].widget.attrs.update({'class': 'form-control'})
        self.fields['descricao'].widget.attrs.update({'class': 'form-control'})
        # Para campos de arquivo, o Bootstrap pode ter classes específicas ou o estilo padrão já é adequado
        # self.fields['imagem'].widget.attrs.update({'class': 'form-control-file'})
        self.fields['link_repositorio'].widget.attrs.update({'class': 'form-control'})
        self.fields['link_aplicacao'].widget.attrs.update({'class': 'form-control'})
        # Para o campo de tecnologias (CheckboxSelectMultiple), a estilização é melhor no template
        self.fields['destaque'].widget.attrs.update({'class': 'form-check-input'}) 