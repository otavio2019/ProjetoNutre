from django.db import models
from django.urls import reverse

class Tecnologia(models.Model):
    nome = models.CharField(max_length=50, unique=True, verbose_name="Nome da Tecnologia")
    # Adicionando campo de cor com choices para classes de badges do Bootstrap
    COR_CHOICES = [
        ('primary', 'Azul Primário'),
        ('secondary', 'Cinza Secundário'),
        ('success', 'Verde Sucesso'),
        ('danger', 'Vermelho Perigo'),
        ('warning', 'Amarelo Aviso'),
        ('info', 'Azul Informação'),
        ('light', 'Branco/Cinza Claro'),
        ('dark', 'Preto/Cinza Escuro'),
    ]
    cor = models.CharField(
        max_length=10,
        choices=COR_CHOICES,
        default='secondary', # Cor padrão
        help_text="Escolha uma cor para o badge da tecnologia."
    )

    def __str__(self):
        return self.nome

    class Meta:
        verbose_name = "Tecnologia"
        verbose_name_plural = "Tecnologias"
        ordering = ['nome']

class Projeto(models.Model):
    titulo = models.CharField(max_length=100, verbose_name="Título")
    descricao = models.TextField(verbose_name="Descrição")
    imagem = models.ImageField(upload_to='project_images/', verbose_name="Imagem do Projeto", help_text="Envie uma imagem para o projeto.")
    data_criacao = models.DateField(auto_now_add=True, verbose_name="Data de Criação")
    link_repositorio = models.URLField(blank=True, null=True, verbose_name="Link do Repositório")
    link_aplicacao = models.URLField(blank=True, null=True, verbose_name="Link da Aplicação")
    tecnologias = models.ManyToManyField(Tecnologia, blank=True, verbose_name="Tecnologias Utilizadas")
    # Adicionando um campo para destacar a dieta na home, se necessário
    destaque = models.BooleanField(default=False, verbose_name="Destacar na Home?")

    def __str__(self):
        return self.titulo

    def get_absolute_url(self):
        return reverse('projects:project-detail', kwargs={'pk': self.pk})

    class Meta:
        verbose_name = "Projeto"
        verbose_name_plural = "Projetos"
        ordering = ['-data_criacao', 'titulo'] 